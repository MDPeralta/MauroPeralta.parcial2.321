
package parcialnaves;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;


public class Inventario<T> implements Serializable {
    
    List<T> listaNaves = new ArrayList<>(); 
    
    void agregar(T nave){
        if(nave == null){
            throw new NoSuchElementException("Pasaste un null en vez de una nave");
        }
        listaNaves.add(nave);
    }
    
    void eliminar(int indice){
        validarIndice(indice);
        listaNaves.remove(indice);
    }
    
    private void validarIndice(int indice) {
    if (indice < 0 || indice >= listaNaves.size()) {
        throw new IndexOutOfBoundsException("Indice Invalido");
    }
    }
    
    public void ordenar(){
        listaNaves.sort(null);
    }
    
    public void ordenar(Comparator<T> comparator){
        listaNaves.sort(comparator);
    }
    
    public void paraCadaElemento(Consumer<? super T> accion) {
    for (T elemento : listaNaves) {
        accion.accept(elemento);
        }    
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
    List<T> listaaux = new ArrayList<>();
    for(T elementos : listaNaves){
        if(criterio.test(elementos)){
            listaaux.add(elementos);
        }
    }
    return listaaux; 
    }
    
    public void transformar(Function<T, T> transformacion) {
    for (int i = 0; i < listaNaves.size(); i++) {
        T elementoTransformado = transformacion.apply(listaNaves.get(i)); 
        listaNaves.set(i, elementoTransformado); 
        }
    }
    
    public void guardarEnArchivo (String path) throws IOException {
    try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
        salida.writeObject(listaNaves);
        System.out.println("Archivo serializado .");
        }
    }
    
    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
    try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
        this.listaNaves = (List<T>) entrada.readObject();
        System.out.println("Archivo binario cargado exitoso.");
        }
    }
    
    public void guardarEnCSV(String path) {
        if (crearArchivoCsv(path)) {
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
                System.out.println("Se guardaron con exito.\n");
                bw.write("id,nombre,capacidad de tripulacion,categoria\n");
                for (T t : listaNaves) {
                    if (t instanceof CSVSerializable csvNave) {
                        bw.write(csvNave.toCSV() + "\n");
                    }
                }
            } catch (IOException e) {
                System.out.println("Error al guardar en el archivo: " + e.getMessage());
            }
        }
    }

    private boolean crearArchivoCsv(String path) {
        File archivo = new File(path);
        try {
            if (archivo.exists()) {
                System.out.println("Archivo existente.");
                return true;
            } else if (archivo.createNewFile()) {
                System.out.println("Se creo el archivo nuevo exitosamente.");
                return true;
            }
        } catch (IOException e) {
            System.out.println("Hubo un error al intentar crear el archivo");
        }
        return false;    
    }
    
    public void cargarDesdeCSV(String path) {
    List<NaveEspacial> listaRetornable = new ArrayList<>();
    try (BufferedReader br = new BufferedReader(new FileReader(path))) {
        String linea;
        br.readLine();
        while ((linea = br.readLine()) != null) {
            procesarLineaParaCSV(linea, listaRetornable);
        }
    } catch (IOException e) {
        System.out.println("Error al cargar en el archivo: " + e.getMessage());
    }
    }
    
    public static void procesarLineaParaCSV(String linea, List<NaveEspacial> lista) {
    linea = limpiarLinea(linea);
    try {
        NaveEspacial e = NaveEspacial.fromCSV(linea);
        lista.add(e);
    } catch (IllegalArgumentException e) {
        System.out.println("Error al procesar la línea: " + linea + ", " + e.getMessage());
    }
    }
    
    private static String limpiarLinea(String linea) {
    if (linea.endsWith("\n")) {
        return linea.substring(0, linea.length() - 1);
    }
    return linea;
    }
}


