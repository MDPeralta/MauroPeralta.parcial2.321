
package parcialnaves;

import java.io.IOException;

public class TestParcialNaves {


public static void main(String[] args) {
        try {
            // Crear un inventario de naves espaciales
            Inventario<NaveEspacial> inventarioNaves = new Inventario<>();
            inventarioNaves.agregar(new NaveEspacial(1, "USS Enterprise", 50, Categoria.CIENTIFICA));
            inventarioNaves.agregar(new NaveEspacial(2, "Millennium Falcon", 3, Categoria.TRANSPORTE));
            inventarioNaves.agregar(new NaveEspacial(3, "TIE Fighter", 1, Categoria.MILITAR));
            inventarioNaves.agregar(new NaveEspacial(4, "X-Wing", 2, Categoria.MILITAR));
            inventarioNaves.agregar(new NaveEspacial(5, "Discovery One", 100, Categoria.CIENTIFICA));

            // Mostrar todas las naves en el inventario
            System.out.println("Inventario de naves espaciales:");
            inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));
            
            // Filtrar naves por categoría MILITAR
            System.out.println("\nNaves de la categoría MILITAR:");
            inventarioNaves.filtrar(nave ->((NaveEspacial) nave).getCategoria() == Categoria.MILITAR)
                    .forEach(nave -> System.out.println(nave));

            // Filtrar naves cuyo nombre contiene "Falcon"
            System.out.println("\nNaves cuyo nombre contiene 'Falcon':");
            inventarioNaves.filtrar( nave -> ((NaveEspacial) nave).getNombre().contains("Falcon") )
                    .forEach(nave -> System.out.println(nave));

            // Ordenar naves de manera natural (por id)
            System.out.println("\nNaves ordenadas de manera natural (por id):");
            inventarioNaves.ordenar();
            inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

            // Ordenar naves por nombre utilizando un Comparator
            System.out.println("\nNaves ordenadas por tripulacion:");
            inventarioNaves.ordenar((nave1, nave2) -> Integer.compare(nave1.getCapacidadTripulacion(), nave2.getCapacidadTripulacion()));
            inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

            // Transformar los elementos de categoria a MILITAR de todas las naves. 
            System.out.println("\nTransformando todas las naves a tipo MILITAR:");
            inventarioNaves.transformar(nave -> {
                nave.setCategoria(Categoria.MILITAR); 
                return nave;
            });

            System.out.println("\nNaves después de la transformación:");
            inventarioNaves.paraCadaElemento(System.out::println);

            System.out.println("Guardando archivo binario");
            // Guardar el inventario en un archivo binario
            inventarioNaves.guardarEnArchivo("C:/Users/mauro peralta/Documents/NetBeansProjects/ParcialNaves/naves.dat");
            
            System.out.println("Cargando el inventario desde archivo binario");
            // Cargar el inventario desde el archivo binario
            Inventario<NaveEspacial> inventarioCargado = new Inventario<>();
            inventarioCargado.cargarDesdeArchivo("C:/Users/mauro peralta/Documents/NetBeansProjects/ParcialNaves/src/naves.dat");
            System.out.println("\nNaves cargadas desde archivo binario:");
            inventarioCargado.paraCadaElemento(nave -> System.out.println(nave));

            // Guardar el inventario en un archivo CSV
            inventarioNaves.guardarEnCSV("C:/Users/mauro peralta/Documents/NetBeansProjects/ParcialNaves/src/data/naves.csv");

            // Cargar el inventario desde el archivo CSV
            inventarioCargado.cargarDesdeCSV("C:/Users/mauro peralta/Documents/NetBeansProjects/ParcialNaves/src/data/naves.csv");
            System.out.println("\nNaves cargadas desde archivo CSV:");
            inventarioCargado.paraCadaElemento(nave -> System.out.println(nave));

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}