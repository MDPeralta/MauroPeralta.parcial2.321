package parcialnaves;

public class NaveEspacial implements Comparable<NaveEspacial> {

    
    private int id;
    private String nombre;
    private int capacidadTripulacion;
    private Categoria categoria;

    public NaveEspacial(int id, String nombre, int capacidadTripulacion, Categoria categoria) {
        this.id = id;
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.categoria = categoria;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }
    @Override
    public String toString() {
        return "NaveEspacial{" + "nombre=" + nombre + ", categoria=" + categoria + ", capacidadTripulacion=" + capacidadTripulacion + '}';
    }

    @Override
    public int compareTo(NaveEspacial o) {
        return Integer.compare(id, o.id);
    }
    
    
    public static NaveEspacial fromCSV(String linea) {
    String[] data = linea.split(",");
    if (data.length != 4) {
        throw new IllegalArgumentException("La línea no tiene el formato esperado: " + linea);
    }
    try {
        int id = Integer.parseInt(data[0]);
        String nombre = data[1];
        int capacidadTripulacion = Integer.parseInt(data[2]);
        Categoria categoria = Categoria.valueOf(data[3]);
        return new NaveEspacial(id, nombre, capacidadTripulacion, categoria);
    } catch (NumberFormatException e) {
        throw new IllegalArgumentException("Error en formato numérico: " + e.getMessage());
    } catch (IllegalArgumentException e) {
        throw new IllegalArgumentException("Error en sector o formato general: " + e.getMessage());
    }
    }
    
    
    
}
