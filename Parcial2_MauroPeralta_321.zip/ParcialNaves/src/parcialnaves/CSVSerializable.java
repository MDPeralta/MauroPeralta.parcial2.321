
package parcialnaves;

@FunctionalInterface
public interface CSVSerializable {
    String toCSV();
}
